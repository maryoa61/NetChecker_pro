package com.netchecker.presentation

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.netchecker.data.database.ProxyConfigEntity

@Composable
fun ProxiesSection(
    state: ScanUiState,
    proxies: List<ProxyConfigEntity>,
    onRunThroughputTest: (Int, Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(proxies) { proxy ->
            val result = state.throughputResults[proxy.id]
            val isTesting = state.testingThroughputId == proxy.id

            // نمایش کارت هر پروکسی
            Card(
                modifier = Modifier.fillMaxWidth().clickable { 
                    onRunThroughputTest(proxy.id, proxy.currentPing, proxy.isWorking) 
                }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = proxy.remarks)
                    if (isTesting) {
                        Text(text = "${state.throughputPhase} (${state.throughputProgress}%)")
                        LinearProgressIndicator(progress = state.throughputProgress / 100f)
                    } else if (result != null) {
                        Text(text = "Speed: ${result.first} Mbps | Loss: ${result.second}%")
                    }
                }
            }
        }
    }
}