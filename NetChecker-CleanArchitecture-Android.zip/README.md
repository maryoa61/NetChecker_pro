# NetChecker Cloudflare Android Client

This is a production-ready Native Android app structured in clear Clean Architecture implementing a multi-threaded Cloudflare IP scanner on port 443 with Live Jetpack Compose UI.

## Build Prerequisites
- Android Studio Koala / Ladybug or newer
- JDK 17 (pre-configured in modern Android Studio gradle toolchain)